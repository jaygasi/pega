// TypeScript wrapper re-export for Storybook imports
export { default } from './index';
