// ES module wrapper to re-export the TSX component for Storybook/story imports
// Use ES re-export to satisfy eslint and tooling that expect JS files.
export { default } from './index';
