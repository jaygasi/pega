declare module '*.worker.min.js' {
  const content: string;
  export = content;
}
